import os
from main import Main

dir_path = "./inputs/"

for file_path in os.listdir(dir_path):
    # check if current file_path is a file
    if os.path.isfile(os.path.join(dir_path, file_path)):
        # add filename to list
        #res.append(file_path)
        Main(dir_path + file_path)
        print(file_path)