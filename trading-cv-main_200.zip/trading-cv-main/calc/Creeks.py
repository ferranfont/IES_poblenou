from math import atan2, degrees, sqrt, tan, pi
import Variables


class Creek:
    def __init__(self, impulseIndex, startIndex, startPoint, endPoint):
        self.impulseIndex = impulseIndex
        self.startIndex = startIndex
        self.startPoint = startPoint
        self.endPoint = endPoint

    def getLinePoints(self):
        return self.startPoint, self.endPoint



class Creeks:
    def __init__(self, extrems, impulses):
        self.extrems = extrems
        self.impulses = impulses
        self.creeks = []

        #self.method1()
        #self.method2()
        self.method3()



    # Constant degree angle from N_EXTREMS_CREEK first extrems in creek area
    def method3(self):
        for i in range(0, len(self.impulses)):
            impulse = self.impulses[i]
            startIndex = impulse.creekStartIndex
            maxIndex = startIndex + (Variables.N_EXTREMS_CREEK-1)*2
            if maxIndex < len(self.extrems) - 1 and maxIndex <= impulse.creekEndIndex:
                sumYs = 0
                for i in range(0, Variables.N_EXTREMS_CREEK):
                    sumYs = sumYs + self.extrems[startIndex + i*2].y
                sumYs = sumYs / Variables.N_EXTREMS_CREEK
                startPoint = (self.extrems[startIndex].x, (int)(sumYs))

                angle = Variables.CREEK_MAX_ANGLE
                if impulse.isUp:
                    angle = -angle
                endPoint = self.findPointInLineAngle(startPoint, angle, self.extrems[impulse.creekEndIndex].x)
                self.creeks.append(Creek(i, startIndex, startPoint, endPoint))

    # Constant degree angle from first extrem in creek area
    def method2(self):
        for i in range(0, len(self.impulses)):
            impulse = self.impulses[i]
            startIndex = impulse.creekStartIndex
            startPoint = (self.extrems[startIndex].x,
                            self.extrems[startIndex].y)
            angle = Variables.CREEK_MAX_ANGLE
            if impulse.isUp:
                angle = -angle
            endPoint = self.findPointInLineAngle(startPoint, angle, self.extrems[impulse.creekEndIndex].x)
            self.creeks.append(Creek(i, startIndex, startPoint, endPoint))

    # Filter first 2 extrems that are aligned with correct slope
    def method1(self):
        for i in range(0, len(self.impulses)):
            extremsCreek = self.findExtremsCreek(self.impulses[i])
            extremsCreek = self.filterSlopes(
                extremsCreek, self.impulses[i].isUp)
            if len(extremsCreek) >= 2:
                startIndex = extremsCreek[0]
                endIndex = extremsCreek[len(extremsCreek)-1]
                startPoint = (self.extrems[startIndex].x,
                              self.extrems[startIndex].y)
                endPoint = (self.extrems[endIndex].x,
                              self.extrems[endIndex].y)

                endPoint = self.findPointInLine(startPoint, endPoint, self.extrems[self.impulses[i].creekEndIndex].x)
                self.creeks.append(
                    Creek(i, startIndex, startPoint, endPoint))

    # Find point in line at x coordinate
    def findPointInLine(self, ptLine0, ptLine1, xCoord):
        # Line equation: y = ax + b
        a = (ptLine0[1] - ptLine1[1]) / (ptLine0[0] - ptLine1[0])
        b = ptLine0[1] - a * ptLine0[0]
        return xCoord, (int)(a * xCoord + b)

    # Find point in line at x coordinate
    def findPointInLineAngle(self, ptLine0, angle, xCoord):
        # Line equation: y = ax + b
        a = tan(angle * pi / 180)
        b = ptLine0[1] - a * ptLine0[0]
        return xCoord, (int)(a * xCoord + b)


    # Find all extrems after creek
    def findExtremsCreek(self, impulse):
        extremsCreek = []
        for i in range(impulse.creekStartIndex, impulse.creekEndIndex):
            if impulse.isUp and not self.extrems[i].isMax:
                extremsCreek.append(i)
            elif not impulse.isUp and self.extrems[i].isMax:
                extremsCreek.append(i)

            if len(extremsCreek) > 4:
                break
        return extremsCreek

    # Filter first 2 extrems that are aligned with correct slope
    def filterSlopes(self, extremsCreek, impulseUp):
        for i in range(0, len(extremsCreek)-1):
            for j in range(i+1, len(extremsCreek)):
                slopeDeg = self.calcSlopeDeg(extremsCreek[i], extremsCreek[j])
                if impulseUp and slopeDeg >= 0 and slopeDeg <= Variables.CREEK_MAX_ANGLE:
                    return [extremsCreek[i], extremsCreek[j]]
                elif not impulseUp and slopeDeg <= 0 and slopeDeg >= -Variables.CREEK_MAX_ANGLE:
                    return [extremsCreek[i], extremsCreek[j]]

        return []

    def calcSlopeDeg(self, idx0, idx1):
        distX = self.extrems[idx1].x - self.extrems[idx0].x
        # Y axis is inverted
        distY = self.extrems[idx0].y - self.extrems[idx1].y

        slopeDeg = degrees(atan2(distY,  distX))
        return slopeDeg

    def getCreeks(self):
        return self.creeks
