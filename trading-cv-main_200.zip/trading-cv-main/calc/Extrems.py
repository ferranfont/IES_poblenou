from operator import attrgetter
import Variables
BLACK_COLOR = 55  # Below this number is considered black color


class Extrem:
    def __init__(self, x, y, isMax):
        self.x = x
        self.y = y
        self.isMax = isMax


class Extrems:
    def __init__(self, frame, width, height):
        self.WINDOW_SIZE = int(width / 100)

        # Min Y and X distances in pixels between maxs mins. Otherwise do not consider.
        self.MIN_DIST_MAXMIN_Y = int (height / 20)

        self.extrems = []
        for x in range(self.WINDOW_SIZE, width-self.WINDOW_SIZE):
            for y in range(1, height-1):
                col = frame[y, x]
                colPrevY = frame[y-1, x]
                colPrevX = frame[y, x-1]
                colNextY = frame[y+1, x]
                if col > BLACK_COLOR and colPrevY <= BLACK_COLOR and colPrevX <= BLACK_COLOR:
                    isMax = self.checkMax(frame, x, y)
                    if isMax:
                        self.extrems.append(Extrem(x, y, True))
                        xLastFound = x
                        continue
                elif col > BLACK_COLOR and colNextY <= BLACK_COLOR and colPrevX <= BLACK_COLOR:
                    isMin = self.checkMin(frame, x, y)
                    if isMin:
                        self.extrems.append(Extrem(x, y, False))
                        xLastFound = x
                        continue

        # Sort by x
        sorted(self.extrems, key=attrgetter("x"))
        self.extrems = self.filter()

    def checkMax(self, frame, xCheck, yCheck):
        # Check in previous rows
        for x in range(xCheck-self.WINDOW_SIZE, xCheck+self.WINDOW_SIZE):
            for y in range(yCheck-self.WINDOW_SIZE, yCheck - 1):
                # if not (y >= yCheck and x >= xCheck - 2 and x <= xCheck + 2):
                if x != xCheck and y != yCheck:
                    col = frame[y, x]
                    if col > BLACK_COLOR:
                        return False

        return True

    def checkMin(self, frame, xCheck, yCheck):
        # Check in next rows
        for x in range(xCheck-self.WINDOW_SIZE, xCheck+self.WINDOW_SIZE):
            for y in range(yCheck + 1, yCheck+self.WINDOW_SIZE):
                # if not (y <= yCheck and x >= xCheck - 2 and x <= xCheck + 2):
                if x != xCheck and y != yCheck:
                    col = frame[y, x]
                    if col > BLACK_COLOR:
                        return False

        return True

    def getExtrems(self):
        return self.extrems

    def max(self, extrem1, extrem2):
        if extrem1.y <= extrem2.y:
            return extrem1
        else:
            return extrem2

    def min(self, extrem1, extrem2):
        if extrem1.y >= extrem2.y:
            return extrem1
        else:
            return extrem2

    def filter(self):
        newExtrems = []
        # Filter min-max-min-max sequence
        extrem = self.extrems[0]
        for e in range(1, len(self.extrems)):
            if extrem.isMax == self.extrems[e].isMax:
                if extrem.isMax:
                    extrem = self.max(extrem, self.extrems[e])
                else:
                    extrem = self.min(extrem, self.extrems[e])
            else:
                yDist = abs(extrem.y - self.extrems[e].y)
                if yDist > self.MIN_DIST_MAXMIN_Y:
                    newExtrems.append(extrem)
                    extrem = self.extrems[e]

        return newExtrems
