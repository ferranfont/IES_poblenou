from math import atan2, degrees
import Variables

COLORS_ARRAY = [(0, 0, 255), (255, 0, 0), (0, 255, 0), (90, 0, 90), (0, 50, 100), (0, 96, 10)]

class Impulse:
    def __init__(self, startIndex, endIndex, isUp, yImpulse, xImpulse):
        self.startIndex = startIndex
        self.endIndex = endIndex
        self.creekStartIndex = -1
        self.creekEndIndex = -1
        self.isUp = isUp
        self.yImpulse = yImpulse
        self.xImpulse = xImpulse

    def overlaps(self, other):
        return (other.startIndex >= self.startIndex and other.startIndex < self.endIndex) or (other.endIndex > self.startIndex and other.endIndex <= self.endIndex)


class Impulses:
    def __init__(self, extrems):
        self.extrems = extrems
        self.impulses = []

        # Iterate extrems finding impulses
        for i in range(0, len(self.extrems)):
            idxImpulse = self.findDistantIndex(i)
            if idxImpulse != -1:
                self.impulses.append(
                    Impulse(i, idxImpulse, not self.extrems[i].isMax, abs(
                        self.extrems[idxImpulse].y - self.extrems[i].y), abs(
                        self.extrems[idxImpulse].x - self.extrems[i].x)))

        # Filter overlapping
        self.filterOverlapping()

        # Filter if impulse is a retroces and not really an impulse
        self.filterRetroces()

        # Filter if new impulse is already contained in previous impulse
        self.filterContained()

        self.setColors()

        # Calc creek area limits
        self.calcCreekLimits()

    # Find distant extrem between limits IMPULSE_MAX_X and IMPULSE_MIN_Y
    def findDistantIndex(self, index):
        distantExtrem = -1
        yDistMax = 0
        for i in range(index+1, len(self.extrems)):
            extrem = self.extrems[i]
            if extrem.isMax != self.extrems[index].isMax:
                yDist = abs(extrem.y - self.extrems[index].y)
                if yDist > Variables.IMPULSE_MIN_Y and yDist > yDistMax:
                    xDist = abs(extrem.x - self.extrems[index].x)
                    if xDist > 0:
                        angleDeg = degrees(atan2(yDist, xDist))
                        if angleDeg > Variables.IMPULSE_MIN_ANGLE:
                            yDistMax = yDist
                            distantExtrem = i

        return distantExtrem

    def initMarkToDel(self):
        markToDel = []
        for i in range(0, len(self.impulses)):
            markToDel.append(False)
        return markToDel

    def applyMarkToDel(self, markToDel):
        newImpulses = []
        for i in range(0, len(self.impulses)):
            if not markToDel[i]:
                newImpulses.append(self.impulses[i])
        self.impulses = newImpulses


    def filterOverlapping(self):
        markToDel = self.initMarkToDel()

        # Filter overlapping impulses in X axis
        for i in range(0, len(self.impulses)-1):
            for j in range(i+1, len(self.impulses)):
                if (self.impulses[i].overlaps(self.impulses[j])):
                    if self.impulses[j].yImpulse > self.impulses[i].yImpulse:
                        markToDel[i] = True
                        break
                    else:
                        markToDel[j] = True
        self.applyMarkToDel(markToDel)

    def filterRetroces(self):
        markToDel = self.initMarkToDel()

        for i in range(1, len(self.impulses)):
            if self.impulses[i].isUp != self.impulses[i-1].isUp:
                if self.impulses[i].isUp and self.extrems[self.impulses[i].endIndex].y > self.extrems[self.impulses[i-1].startIndex].y:
                    markToDel[i] = True
                    break
                elif not self.impulses[i].isUp and self.extrems[self.impulses[i].endIndex].y < self.extrems[self.impulses[i-1].startIndex].y:
                    markToDel[i] = True
                    break

        self.applyMarkToDel(markToDel)

    # Check if retroces using end index of impulse and previous extrems
    def isRetroces(self, endIdx, prevIdx):
        if self.extrems[endIdx].isMax and self.extrems[prevIdx].y < self.extrems[endIdx].y:
            return True
        elif not self.extrems[endIdx].isMax and self.extrems[prevIdx].y > self.extrems[endIdx].y:
            return True
        return False

    # Filter if overlaps with previous impulse and previous is stronger
    def filterContained(self):
        markToDel = self.initMarkToDel()

        for i in range(1, len(self.impulses)):
            prev = i-1
            while markToDel[prev] and prev > 0:
                prev = prev - 1

            if self.impulses[i].yImpulse < self.impulses[prev].yImpulse:
                overlap = self.findOverlapPercentageY(self.impulses[i], self.impulses[prev])
                if overlap > 0.5:
                    markToDel[i] = True

        self.applyMarkToDel(markToDel)

    def findOverlapPercentageY(self, impulse0, impulse1):
        ys = [self.extrems[impulse0.startIndex].y,self.extrems[impulse0.endIndex].y,self.extrems[impulse1.startIndex].y,self.extrems[impulse1.endIndex].y]
        ys.sort()
        return abs(ys[1]-ys[2])/abs(ys[0]-ys[3])

    def setColors(self):
        # Set limit into next impulse
        for i in range(0, len(self.impulses)):
            self.impulses[i].color = COLORS_ARRAY[i % len(COLORS_ARRAY)]


    # Calculate region where creek can be
    def calcCreekLimits(self):
        # Set limit into next impulse
        nImpulses = len(self.impulses)
        if nImpulses == 0:
            return
        for i in range(0, nImpulses-1):
            self.impulses[i].creekEndIndex = self.impulses[i+1].endIndex
        self.impulses[nImpulses-1].creekEndIndex = len(self.extrems) - 1

        # Check if price reversal after impulse > 68.1
        for i in range(0, nImpulses):
            impulse = self.impulses[i]
            for j in range(impulse.endIndex, impulse.creekEndIndex):
                if impulse.isUp and not self.extrems[j].isMax:
                    yDist = -100.0*(self.extrems[impulse.endIndex].y - self.extrems[j].y) / impulse.yImpulse
                    if (yDist > Variables.MAX_REVERSAL_PERC):
                        self.impulses[i].creekEndIndex = j
                        break
                elif not impulse.isUp and self.extrems[j].isMax:
                    yDist = -100.0*(self.extrems[j].y - self.extrems[impulse.endIndex].y) / impulse.yImpulse
                    if (yDist > Variables.MAX_REVERSAL_PERC):
                        self.impulses[i].creekEndIndex = j
                        break

        # Creek start index is when distance between min - max already passed the threshold
        # and is near the impulse end, not near impulse start
        for i in range(0, nImpulses):
            self.impulses[i].creekStartIndex = self.impulses[i].endIndex
            impulse = self.impulses[i]
            for j in range(impulse.startIndex+1, impulse.endIndex-1):
                yDistStart = abs(self.extrems[impulse.startIndex].y - self.extrems[j].y)
                yDistEnd = 0
                if impulse.isUp:
                    yDistEnd = -(self.extrems[impulse.endIndex].y - self.extrems[j].y)
                else:
                    yDistEnd = -(self.extrems[j].y - self.extrems[impulse.endIndex].y)

                if yDistStart > Variables.IMPULSE_MIN_Y and yDistEnd/impulse.yImpulse < 0.5:
                    self.impulses[i].creekStartIndex = j
                    break

            if self.impulses[i].creekStartIndex < len(self.extrems) - 1:
                self.impulses[i].creekStartIndex = self.impulses[i].creekStartIndex + 1

    def getImpulses(self):
        return self.impulses
