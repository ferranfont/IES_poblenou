FILENAME = "./inputs/crude5.png"

# Impulses
# Min pixels to consider an impulse in Y axis
IMPULSE_MIN_Y = 200
# Min angle in degree to filter impulse
IMPULSE_MIN_ANGLE = 55
# Discards this impulse if price reverses this percentage of the impulse
MAX_REVERSAL_PERC = 68.1

# Creeks
CREEK_MAX_ANGLE = 10  # Max angle in degrees for creek.
# If impulse UP: angle>0 and angle<CREEK_MAX_ANGLE.
# If impulse DOWN: angle<0 and angle>-CREEK_MAX_ANGLE.

N_EXTREMS_CREEK = 1 # Number of extrems to average creek line
