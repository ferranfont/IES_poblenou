# trading-cv

1-Make sure python is installed on your computer
2-Install requirements to run the program
```
pip install -r requirements.txt
```
3-Run main file by running command python main.py in the terminal

```
python main.py
or
python3 main.py
```
4-Program variables are defined in file Variables.py


