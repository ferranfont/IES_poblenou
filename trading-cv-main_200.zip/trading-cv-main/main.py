import cv2
import Variables
from calc.Extrems import Extrems
from calc.Impulses import Impulses
from calc.Creeks import Creeks
import time
import os

BLACK_COLOR = 55


class Main:

    bgColor = "black"
    fgColor = "white"

    def __init__(self, filePath):

        # capturing video
        img = cv2.imread(filePath, cv2.IMREAD_COLOR)

        baseName = os.path.basename(filePath)
        inputName = os.path.splitext(baseName)

        startTime = time.time()
        # directory to store screenshots
        save_directory = 'images'
        os.makedirs(save_directory, exist_ok=True)

        height, width, c = img.shape

        # To gray scale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        extrems = Extrems(gray, width, height).getExtrems()
        # displaying all the local extremes
        for point in extrems:
            if point.isMax:
                cv2.circle(img, (point.x, point.y - 3),
                           5, (255, 255, 0), 1)
            else:
                cv2.circle(img, (point.x, point.y + 3),
                           5, (255, 0, 255), 1)

        impulses = Impulses(extrems).getImpulses()
        for i in range(0, len(impulses)):
            impulse = impulses[i]
            startPoint = (extrems[impulse.startIndex].x,
                          extrems[impulse.startIndex].y)
            endPoint = (extrems[impulse.endIndex].x,
                        extrems[impulse.endIndex].y)
            cv2.line(img, startPoint, endPoint, impulse.color, 2)

            # Draw creek area
            cv2.line(img, (extrems[impulse.creekStartIndex].x, i*4), (extrems[impulse.creekEndIndex].x, i*4), impulse.color, 4)

        creeks = Creeks(extrems, impulses).getCreeks()
        for creek in creeks:
            startPoint, endPoint = creek.getLinePoints()
            cv2.line(img, startPoint, endPoint, (0, 255, 255), 2)

        screenshot_path = os.path.join(
            save_directory, f'{inputName[0]}_{int(time.time())}.png')
        cv2.imwrite(screenshot_path, img)


    def main():
        pass


run = Main(Variables.FILENAME)
