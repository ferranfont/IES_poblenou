#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class AATradingLinesStrat : Strategy
	{
		private AATradingLines AATradingLines1;

		private double prevPrice, prevCreekSell, prevCreekBuy, prevSlopeSell, prevSlopeBuy, prevRoturaSell, prevRoturaBuy;
		
		private Order[] ordersCreek = new Order[3];
		private Order[] ordersRotura;
		
		private int counter = 1;
		
		private bool[] tradingEnabled = new bool[3];
		
		private System.Windows.Forms.Timer myTimer = new System.Windows.Forms.Timer();
		
		protected override void OnStateChange()
		{
			Print("OnStateChange " + State);
			Print("Orders " + ordersCreek[0] + " " + ordersCreek[1] + " " + ordersCreek[2]);
			if (State == State.SetDefaults)
			{
				Description			= "AATradingLinesStrat Indicator by Ferran & Jordi";
				Name				= "AATradingLinesStrat";
				Calculate									= Calculate.OnEachTick;
				EntriesPerDirection							= 99;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 0;
				
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				UseLimitOrders								= true;
				TradeCreekLots								= 1;
				TradePreCreekDistance						= 2;
				TradePreCreekLots							= 1;
				TradePostCreekDistance						= 10;
				TradePostCreekLots							= 1;
				TakeProfitCreekDistance_1					= 18;
				TakeProfitCreekDistance_2					= 20;
				StopLossCreekDistance						= 20;	
				ReactivateCreekDistance					    = 10;
				
				RoturaShift									= 2;
				RoturaLots									= 1;
				RoturaNTrades								= 0;
				RoturaDistTrades							= 5;
				RoturaTakeProfit							= 20;
				RoturaStopLoss								= 20;
				
			}
			else if (State == State.Configure)
			{
				AATradingLines1				= AATradingLines(Close, 5, 1, 25, true);
				AddChartIndicator(AATradingLines1);			
				this.ordersRotura = new Order[RoturaNTrades];
				this.tradingEnabled[0] = true;
				this.tradingEnabled[1] = true;
				this.tradingEnabled[2] = true;
				
				// Initiate our Timer object with an interval of 1000ms (1 second)
				myTimer.Tick += new EventHandler(TimerEventProcessor);
				myTimer.Interval = 200;
				myTimer.Start();				

			}
			else if (State == State.DataLoaded)
			{				

				//SetProfitTarget("", CalculationMode.Ticks, Target);
				//SetStopLoss("", CalculationMode.Ticks, Stop, false);
			}			
			else if (State == State.Terminated)
			{
				myTimer.Dispose();
			}			

		}

		// Timer's tick event handler. Called at every tick of 1000ms.
		private void TimerEventProcessor(Object myObject, EventArgs myEventArgs)
		{
			/* Important to use the TriggerCustomEvent() to ensure that NinjaScript indexes and pointers are correctly set.
			Do not process your code here. Process your code in the MyCustomHandler method. */
			TriggerCustomEvent(MyCustomHandler, 0, myTimer.Interval);
		}
		
		private void MyCustomHandler(object state)
		{
			// Informs us of when the event was triggered and of our Timer settings
			//Print("\tTime: " + DateTime.Now);
			//Print("\tTimer Interval: " + state.ToString() + "ms");

			this.strategyCreek();	
			//this.strategyRotura();
		
			this.prevPrice = Input[0];
			this.prevCreekSell = AATradingLines1.SellLineIndication[0];
			this.prevCreekBuy = AATradingLines1.BuyLineIndication[0];
			this.prevSlopeSell = AATradingLines1.SellSlopeIndication[0];
			this.prevSlopeBuy = AATradingLines1.BuySlopeIndication[0];			
			this.prevRoturaSell = AATradingLines1.RoturaSellLineIndication[0];
			this.prevRoturaBuy = AATradingLines1.RoturaBuyLineIndication[0];			
		}
		
		protected override void OnBarUpdate()
		{		
			if (BarsInProgress != 0) 
				return;

			if (CurrentBars[0] < 1)
				return;

			if (State != State.Realtime) {
				// No hacemos trading en histórico, solo realtime	
				//Print(AATradingLines1.SellLineIndication[0] + " " + AATradingLines1.SellLineIndication[1]+ " " + AATradingLines1.SellLineIndication[2] + " " + AATradingLines1.SellLineIndication[3]);
				return;
			}
			
			/*
			this.strategyCreek();	
			//this.strategyRotura();
		
			this.prevPrice = Input[0];
			this.prevCreekSell = AATradingLines1.SellLineIndication[0];
			this.prevCreekBuy = AATradingLines1.BuyLineIndication[0];
			this.prevSlopeSell = AATradingLines1.SellSlopeIndication[0];
			this.prevSlopeBuy = AATradingLines1.BuySlopeIndication[0];			
			this.prevRoturaSell = AATradingLines1.RoturaSellLineIndication[0];
			this.prevRoturaBuy = AATradingLines1.RoturaBuyLineIndication[0];	*/		
		}
		
		// Grid of 3 orders for creek tradings
		private void strategyCreek(){
			//if (Input[0] != this.prevPrice) {
				
				//Print("S_LINE" + AATradingLines1.SellLineIndication[0]);
				//Print("R_LINE" + AATradingLines1.StopLineIndication[0]);
				//Print("BB" + AATradingLines1.BuyLineIndication[0]);
				this.checkOrders();
				if (AATradingLines1.SellLineIndication[0] == 0.0 && AATradingLines1.BuyLineIndication[0] == 0.0) {
					// Clear pending orders	
					this.clearPending();
					// Enable trades for lines drawed in future
					this.tradingEnabled[0] = true;	
					this.tradingEnabled[1] = true;	
					this.tradingEnabled[2] = true;	
					
				} else {
					// Set SL and TP
					this.setCloseTargets();
				}			
			//}						
		}
					
		private void strategyRotura(){
			// Strategy
			if (Input[0] != this.prevPrice) {
				
				//Print("SLINE" + AATradingLines1.SellLineIndication[0]);
				//Print("BB" + AATradingLines1.BuyLineIndication[0]);
				
				this.checkOrdersRotura();
				if (AATradingLines1.RoturaSellLineIndication[0] != 0.0 || AATradingLines1.RoturaBuyLineIndication[0] != 0.0) {
					// Set SL and TP
					this.setCloseTargetsRotura();
				}
			}		
		}
		
		private void drawLimits() {
			Stroke stroke = new Stroke (Brushes.Aqua, DashStyleHelper.Dash, 2);

			if (AATradingLines1.SellLineIndication[0] > 0.0) {
				//Print("Ray " + AATradingLines1.SellLineIndication[0] + " " + AATradingLines1.SellLineIndication[1]);
				Print("AATradingLines1.SellLineIndication[0] " + AATradingLines1.SellLineIndication[0]);
				//Print("tikcs " + Time[0] + " " + Time[100]);
				int periodsBack = 1000;
				double y = AATradingLines1.SellLineIndication[0] - AATradingLines1.SellSlopeIndication[0] * (Time[0].Ticks - Time[periodsBack].Ticks);
				
				Draw.Line(this, "CREEK", periodsBack, y, 0, AATradingLines1.SellLineIndication[0], Brushes.Magenta);
			}
		}
		

		
		private string getEntryName(int index) {
			if (index==0) return "CREEK_" + this.counter;
			else if (index==1) return "PRE_CREEK_" + + this.counter;
			else if (index==2) return "POST_CREEK_" + + this.counter;
			return null;
		}
		
		private double getEntryDistance(int index) {
			if (index==0) return 0.0;
			else if (index==1) return TradePreCreekDistance;
			else if (index==2) return -TradePostCreekDistance;
			return 99999.0;
		}
		
		private int getEntryLots(int index) {
			if (index==0) return TradeCreekLots;
			else if (index==1) return TradePreCreekLots;
			else if (index==2) return TradePostCreekLots;
			return 0;
		}		
		
		private string getEntryNameRotura(int index) {
			return "ROTURA_" + index;
		}
		
		private double getEntryDistanceRotura(int index) {
			return index * RoturaDistTrades;
		}
				
		private void setCloseTargets() {
			
			double tp = 0;
			double tp2 = 0;
			double sl = 0;
			
			//Print("Position.AveragePrice " + Position.AveragePrice);
			//Print("Position.MarketPosition " + Position.MarketPosition);
			
			// Check distance creek to enable trading again
			if (AATradingLines1.SellLineIndication[0] > 0.0){
				double yCreek = AATradingLines1.SellLineIndication[0];
				double limit = yCreek - TickSize * ReactivateCreekDistance;
				if (Input[0] <= limit) {
					this.tradingEnabled[0] = true;	
					this.tradingEnabled[1] = true;	
					this.tradingEnabled[2] = true;	
				}
			}
			if (AATradingLines1.BuyLineIndication[0] > 0.0){
				double yCreek = AATradingLines1.BuyLineIndication[0];
				double limit = yCreek + TickSize * ReactivateCreekDistance;
				if (Input[0] >= limit) {
					this.tradingEnabled[0] = true;	
					this.tradingEnabled[1] = true;	
					this.tradingEnabled[2] = true;	
				}
			}				

			if (Position.MarketPosition != MarketPosition.Flat) {
				if (AATradingLines1.TargetLineIndication[0] > 0) {
					// Profit marcado por la línea T (Target)
					tp = AATradingLines1.TargetLineIndication[0];
					tp2 = tp;
				} else if (TakeProfitCreekDistance_1 > 0.0) {
					if (AATradingLines1.SellLineIndication[0] > 0.0) {
						tp  = Position.AveragePrice - TickSize * TakeProfitCreekDistance_1;		
						tp2 = Position.AveragePrice - TickSize * TakeProfitCreekDistance_2;		
					} else if (AATradingLines1.BuyLineIndication[0] > 0.0){
						tp  = Position.AveragePrice + TickSize * TakeProfitCreekDistance_1;				
						tp2 = Position.AveragePrice + TickSize * TakeProfitCreekDistance_2;		
					}			
				}
				
				if (AATradingLines1.StopLineIndication[0] > 0) {
					// Stop marcado por la línea R (Stop)
					sl = AATradingLines1.StopLineIndication[0];
				} else if (StopLossCreekDistance > 0.0) {
					if (AATradingLines1.SellLineIndication[0] > 0.0) {
						sl = Position.AveragePrice + TickSize * StopLossCreekDistance;			
					} else if (AATradingLines1.BuyLineIndication[0] > 0.0){
						sl = Position.AveragePrice - TickSize * StopLossCreekDistance;					
					}			
				}		
				
				if (AATradingLines1.Close50Series[0] == false) {
					tp2 = tp;
				}
				
				if (tp>0) {
					for (int i=0;i<3;i++) {
						if (ordersCreek[i] != null && ordersCreek[i].Filled > 0) {
							if (tp>0) {
								if (i==0) SetProfitTarget(ordersCreek[i].Name, CalculationMode.Price, tp2);
								else SetProfitTarget(ordersCreek[i].Name, CalculationMode.Price, tp2);
							}
							if (sl>0) {
								SetStopLoss(ordersCreek[i].Name, CalculationMode.Price, sl, true);
							}
						}
					}
				}					
			}
		}
		
		private void setCloseTargetsRotura() {
			
			double tp = 0;
			double sl = 0;
			
			if (Position.MarketPosition != MarketPosition.Flat) {
				if (AATradingLines1.RoturaTargetLineIndication[0] > 0) {
					// Profit marcado por la línea T (Target)
					tp = AATradingLines1.RoturaTargetLineIndication[0];
				} else {
					if (AATradingLines1.RoturaSellLineIndication[0] > 0.0) {
						tp = Position.AveragePrice - TickSize * RoturaTakeProfit;	
					} else {
						double y = AATradingLines1.RoturaBuyLineIndication[0];
						tp = Position.AveragePrice + TickSize * RoturaTakeProfit;			
					}			
				}
				
				if (AATradingLines1.RoturaStopLineIndication[0] > 0) {
					// Stop marcado por la línea R (Stop)
					sl = AATradingLines1.RoturaStopLineIndication[0];
				} else {
					if (AATradingLines1.RoturaSellLineIndication[0] > 0.0) {
						sl = Position.AveragePrice + TickSize * RoturaStopLoss;			
					} else {
						double y = AATradingLines1.RoturaBuyLineIndication[0];
						sl = Position.AveragePrice - TickSize * RoturaStopLoss;					
					}						
				}
				
			
				for (int i=0;i<RoturaNTrades;i++) {
					if (ordersRotura[i] != null) {
						string orderName = ordersRotura[i].Name;
						if (tp>0) SetProfitTarget(orderName, CalculationMode.Price, tp);
						if (sl>0) SetStopLoss(orderName, CalculationMode.Price, sl, true);
					}
				}
			}
		}		
		
		private bool allCreekFilled(){
			return ordersCreek[0] != null && ordersCreek[0].Filled > 0 &&
				ordersCreek[1] != null && ordersCreek[1].Filled > 0 &&
				ordersCreek[2] != null && ordersCreek[2].Filled > 0;
		}
		
		private void checkOrders() {

			for (int i=0;i<3;i++) {
				if (ordersCreek[i] != null && ordersCreek[i].Filled > 0) {
					this.tradingEnabled[i] = false;
					// Already filled update close targets
				} else {
					int lots = this.getEntryLots(i);
					double entryDistance = this.getEntryDistance(i);
					string entryName = this.getEntryName(i);
					
					if (AATradingLines1.SellLineIndication[0] > 0.0){
						double yCreek = AATradingLines1.SellLineIndication[0];
						double limitPriceSell = yCreek - TickSize * entryDistance;
						if (limitPriceSell > Input[0]) {
							if (this.ordersCreek[i] != null) {
								//Print("UpdateShortLimit " + limitPriceSell + " " + entryName);
								ChangeOrder(this.ordersCreek[i], lots, limitPriceSell, 0);
							} else {
								//Print("EnterShortLimit " + limitPriceSell + " " + entryName);
								if (this.tradingEnabled[i]) EnterShortLimit(0,true,lots,limitPriceSell, entryName);
							}
						}
					} else if (AATradingLines1.BuyLineIndication[0] > 0.0){
						double yCreek = AATradingLines1.BuyLineIndication[0];
						double limitPriceBuy = yCreek + TickSize * entryDistance;
						if (limitPriceBuy < Input[0]) {
							if (this.ordersCreek[i] != null) {
								//Print("UpdateShortLimit " + limitPriceSell + " " + entryName);
								ChangeOrder(this.ordersCreek[i], lots, limitPriceBuy, 0);
							} else {
								//Print("EnterLongLimit " + limitPriceBuy + " " + entryName);
								if (this.tradingEnabled[i]) EnterLongLimit(0,true,lots,limitPriceBuy, entryName);	
							}
						}
					} 
				}
			}
		}
		
		private void checkOrdersRotura() {
			for (int i=0;i<RoturaNTrades;i++) {
				if (ordersRotura[i] != null && ordersRotura[i].Filled > 0) {
					// Already filled update close targets
				} else {
					int lots = RoturaLots;
					double entryDistance = this.getEntryDistanceRotura(i);
					string entryName = this.getEntryNameRotura(i);
					
					if (AATradingLines1.RoturaSellLineIndication[0] > 0.0){
						double yRotura = AATradingLines1.RoturaSellLineIndication[0] - TickSize * (RoturaShift + entryDistance);						
						bool cross = checkCross(yRotura, Input[0], this.prevPrice);
						if (cross) {
							Print("Cross sell rotura @" + Input[0].ToString() + " t:" + Time[0]);						
							EnterShort(lots, entryName);
						}
					} else if (AATradingLines1.RoturaBuyLineIndication[0] > 0.0){
						double yRotura = AATradingLines1.RoturaBuyLineIndication[0] + TickSize * (RoturaShift + entryDistance);						
						bool cross = checkCross(yRotura, Input[0], this.prevPrice);
						if (cross) {
							Print("Cross buy rotura @" + Input[0].ToString() + " t:" + Time[0]);						
							EnterLong(lots, entryName);
						}
					} 
				}
			}
		}
	

		private bool checkCross(double y, double currentPrice, double prevPrice) {
			return (currentPrice >= y && prevPrice <= y) || (currentPrice <= y && prevPrice >= y);
		}

		
		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
		{
			Print("OnOrderUpdate order.Name " + order.Name + " orderState " + orderState + " quantity " + quantity + " averageFillPrice " + averageFillPrice) ;
			//Print("filled " + order.Filled);
			updateOrder(order, orderState);

			
			if ((order.Name == "Profit target" || order.Name == "Stop loss") && orderState == OrderState.Filled) {
				// Llegamos a TP o SL -> reiniciamos
				this.resetOrders();
			}
		}

		private void resetOrders() {
			for (int i=0;i<3;i++) {
				ordersCreek[i] = null;
			}
			for (int i=0;i<RoturaNTrades;i++) {
				ordersRotura[i] = null;
			}
			
			this.counter++;			
		}
		
		private void updateOrder(Order order, OrderState orderState) {
			int index = -1;
			string entryName = order.Name;
			if (entryName.IndexOf("CREEK") >= 0) {
				if (entryName.IndexOf("CREEK") == 0) index = 0;
				else if (entryName.IndexOf("PRE_CREEK") == 0) index = 1;
				else if (entryName.IndexOf("POST_CREEK") == 0) index = 2;			
				if (index>=0) {
					if (orderState == OrderState.Cancelled) {
						this.ordersCreek[index] = null;	
					} else {
						this.ordersCreek[index] = order;	
					}
				}				
			}
			else if (entryName.IndexOf("ROTURA") >= 0) {
				index = Convert.ToInt32(entryName.Substring(7));
				if (index>=0) {
					if (orderState == OrderState.Cancelled) {
						this.ordersRotura[index] = null;	
					} else {
						this.ordersRotura[index] = order;	
					}
				}					
			}
		}
		
		private void clearPending() {
			for (int i=0; i<3; i++)	 {
				CancelOrder(this.ordersCreek[i]);	
			}
		}
		#region Properties

		[NinjaScriptProperty]
		[Display(Name="UseLimitOrders", Description="Limit or market orders", Order=1, GroupName="Parameters")]
		public bool UseLimitOrders
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="TradeCreekLots", Description="TradeCreekLots", Order=2, GroupName="Parameters")]
		public int TradeCreekLots
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="TradePreCreekDistance", Description="TradePreCreekDistance", Order=3, GroupName="Parameters")]
		public int TradePreCreekDistance
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="TradePreCreekLots", Description="TradePreCreekLots", Order=4, GroupName="Parameters")]
		public int TradePreCreekLots
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="TradePostCreekDistance", Description="TradePostCreekDistance", Order=5, GroupName="Parameters")]
		public int TradePostCreekDistance
		{ get; set; }	
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="TradePostCreekLots", Description="TradePostCreekLots", Order=6, GroupName="Parameters")]
		public int TradePostCreekLots
		{ get; set; }		
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="TakeProfitCreekDistance_1", Description="TakeProfitCreekDistance_1", Order=7, GroupName="Parameters")]
		public int TakeProfitCreekDistance_1
		{ get; set; }					
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="TakeProfitCreekDistance_2", Description="TakeProfitCreekDistance_2", Order=8, GroupName="Parameters")]
		public int TakeProfitCreekDistance_2
		{ get; set; }	
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="StopLossCreekDistance", Description="StopLossCreekDistance", Order=9, GroupName="Parameters")]
		public int StopLossCreekDistance
		{ get; set; }	

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="ReactivateCreekDistance", Description="Positive distance to reactivate creek orders", Order=10, GroupName="Parameters")]
		public int ReactivateCreekDistance
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="RoturaLots", Description="RoturaLots", Order=11, GroupName="Parameters")]
		public int RoturaLots
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="RoturaNTrades", Description="RoturaNTrades", Order=12, GroupName="Parameters")]
		public int RoturaNTrades
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="RoturaDistTrades", Description="RoturaDistTrades", Order=13, GroupName="Parameters")]
		public int RoturaDistTrades
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="RoturaShift", Description="RoturaShift", Order=14, GroupName="Parameters")]
		public int RoturaShift
		{ get; set; }	
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="RoturaTakeProfit", Description="RoturaTakeProfit", Order=15, GroupName="Parameters")]
		public int RoturaTakeProfit
		{ get; set; }	
		
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="RoturaStopLoss", Description="RoturaStopLoss", Order=16, GroupName="Parameters")]
		public int RoturaStopLoss
		{ get; set; }	
				
		#endregion
	}
}
