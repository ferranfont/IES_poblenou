//
// Copyright (C) 2020, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
	/// <summary>
	/// Trend lines automatically plots recent trends by connect high points together for high trends and connecting low points together for low trends.
	/// </summary>
	public class AATradingLines : Indicator
	{
		private int			lastHighBar			= -1;
		private int			lastLowBar			= -1;
		private double		lastHighPrice		= double.MinValue;
		private double		lastLowPrice		= double.MaxValue;
		private bool?		highTrendIsActive	= null;
		private bool		alertIsArmed;
		private TrendRay	highTrend;
		private TrendRay	lowTrend;
		private TrendQueue	trendLines;
		private Swing		swing;
		
		private int			counter = 0;
		DrawingTools.Line 	lastSellLine = null;
		DrawingTools.Line 	lastBuyLine = null;
		DrawingTools.Line 	lastTargetLine = null;
		DrawingTools.Line 	lastStopLine = null;
		DrawingTools.Line 	lastRoturaSellLine = null;
		DrawingTools.Line 	lastRoturaBuyLine = null;
		DrawingTools.Line 	lastRoturaTargetLine = null;
		DrawingTools.Line 	lastRoturaStopLine = null;
		
		private Series<double> sellLineIndication;
		private Series<double> buyLineIndication;
		private Series<double> targetLineIndication;
		private Series<double> stopLineIndication;
		private Series<double> roturaSellLineIndication;
		private Series<double> roturaBuyLineIndication;
		private Series<double> roturaTargetLineIndication;
		private Series<double> roturaStopLineIndication;
		
		private Series<bool> close50Series;
		
		private Series<double> sellSlopeIndication;
		private Series<double> buySlopeIndication;
		
		// Chart controls
		private System.Windows.Media.SolidColorBrush		activeBackgroundDarkGray;
		private System.Windows.Media.SolidColorBrush		backGroundMediumGray;
		private System.Windows.Controls.Grid				chartGrid;
		private NinjaTrader.Gui.Chart.ChartTab				chartTab;
		private NinjaTrader.Gui.Chart.ChartTrader			chartTraderControl;
		private NinjaTrader.Gui.Chart.Chart					chartWindow;
		private System.Windows.Media.SolidColorBrush		controlLightGray;
		private bool										panelActive;
		private int											tabControlStartRow;
		private System.Windows.Controls.TabItem				tabItem;
		private System.Windows.Media.SolidColorBrush		textColor;
		private System.Windows.Controls.Menu				topMenu;
		private NinjaTrader.Gui.Tools.NTMenuItem			ButtonSellCreek;
		private NinjaTrader.Gui.Tools.NTMenuItem			ButtonBuyCreek;
		private NinjaTrader.Gui.Tools.NTMenuItem			ButtonTarget;
		private NinjaTrader.Gui.Tools.NTMenuItem			ButtonStop;
		private NinjaTrader.Gui.Tools.NTMenuItem			ButtonRoturaSell;
		private NinjaTrader.Gui.Tools.NTMenuItem			ButtonRoturaBuy;		
		private NinjaTrader.Gui.Tools.NTMenuItem			ButtonRoturaTarget;
		private NinjaTrader.Gui.Tools.NTMenuItem			ButtonRoturaStop;			
		private NinjaTrader.Gui.Tools.NTMenuItem			ButtonDeleteAll;
		private NinjaTrader.Gui.Tools.NTMenuItem			ButtonDeleteTrading;
		
		private DateTime now;
		private double priceNow;		
		
		private int SECONDS_LINE_LENGTH = 2000;
		
		private bool close50;
		
		protected override void OnStateChange()
		{
			Print("OnStateChange " + State);
			
			if (State == State.SetDefaults)
			{

				Description			= "AATradingLines";
				Name				= "AATradingLines";
				Calculate			= Calculate.OnEachTick;
				IsOverlay			= true;
			//	DisplayInDataBox	= false;
			//	DrawOnPricePanel	= false;
			//	PaintPriceMarkers	= false;
				Strength			= 5;
				NumberOfTrendLines	= 1;
				OldTrendsOpacity	= 25;
				AlertOnBreak		= false;
				AlertOnBreakSound	= System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", "Alert2.wav");
				TrendLineHighStroke = new Stroke(Brushes.Cyan, 1f);
				TrendLineLowStroke	= new Stroke(Brushes.Goldenrod, 1f);
				AddPlot(Brushes.White, NinjaTrader.Custom.Resource.TrendLinesCurrentTrendLine);
				AddPlot(Brushes.Blue,"Xo Up");
				AddPlot(Brushes.Red,"Xo Dn");
			}
			else if(State == State.Configure)
			{
				/* "this" syncs the Series<bool> to the historical bar object of the indicator. It will generate
				one bool value for every price bar. */
				sellLineIndication = new Series<double>(this);
				buyLineIndication = new Series<double>(this);
				targetLineIndication = new Series<double>(this);
				stopLineIndication = new Series<double>(this);
				roturaSellLineIndication = new Series<double>(this);
				roturaBuyLineIndication = new Series<double>(this);
				roturaTargetLineIndication = new Series<double>(this);
				roturaStopLineIndication = new Series<double>(this);
				
				close50Series = new Series<bool>(this);
				
				sellSlopeIndication = new Series<double>(this);
				buySlopeIndication = new Series<double>(this);				
			}	
				
			else if (State == State.DataLoaded)
			{
				swing		= Swing(Input, Strength);
				trendLines	= new TrendQueue(this, NumberOfTrendLines);
				
				activeBackgroundDarkGray			= new System.Windows.Media.SolidColorBrush(Color.FromRgb(30, 30, 30));
				activeBackgroundDarkGray.Freeze();
				backGroundMediumGray				= new System.Windows.Media.SolidColorBrush(Color.FromRgb(45, 45, 47));
				backGroundMediumGray.Freeze();
				controlLightGray					= new System.Windows.Media.SolidColorBrush(Color.FromRgb(64, 63, 69));
				controlLightGray.Freeze();
				textColor							= new System.Windows.Media.SolidColorBrush(Color.FromRgb(204, 204, 204));
				textColor.Freeze();				
			}
			else if (State == State.Historical)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						CreateWPFControls();
					}));
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						DisposeWPFControls();
					}));
				}
			}			
			
			this.lastSellLine = null;
			this.lastBuyLine = null;
			this.lastTargetLine = null;
			this.lastStopLine = null;
			this.lastRoturaSellLine = null;
			this.lastRoturaBuyLine = null;
			this.lastRoturaTargetLine = null;
			this.lastRoturaStopLine = null;
			
			//this.changeClose50(false);
		}
		
		protected override void OnBarUpdate()
		{
			if (CurrentBar < 0)
				return;
			
			if (this.priceNow == 0) this.changeClose50(false);
			
			this.now = Time[0];
			this.priceNow = Input[0]; // Ask

			this.detectLines();
			
			
			if (this.lastSellLine != null) {
				sellSlopeIndication[0] = this.findSlope(this.lastSellLine);	
				sellLineIndication[0] = this.findYLine(this.lastSellLine);	
			} else {
				sellLineIndication[0] = 0.0;
			}
			
			if (this.lastBuyLine != null) {
				buySlopeIndication[0] = this.findSlope(this.lastBuyLine);					
				buyLineIndication[0] = this.findYLine(this.lastBuyLine);		
			} else {
				buyLineIndication[0] = 0.0;	
			}
			
			if (this.lastTargetLine != null) {
				targetLineIndication[0] = this.findYLine(this.lastTargetLine);	
			} else {
				targetLineIndication[0] = 0.0;
			}
			
			if (this.lastStopLine != null) {
				stopLineIndication[0] = this.findYLine(this.lastStopLine);	
			} else {
				stopLineIndication[0] = 0.0;
			}
			
			if (this.lastRoturaSellLine != null) {
				roturaSellLineIndication[0] = this.findYLine(this.lastRoturaSellLine);	
			} else {
				roturaSellLineIndication[0] = 0.0;
			}
			
			if (this.lastRoturaBuyLine != null) {
				roturaBuyLineIndication[0] = this.findYLine(this.lastRoturaBuyLine);	
			} else {
				roturaBuyLineIndication[0] = 0.0;
			}	
			
			if (this.lastRoturaTargetLine != null) {
				roturaTargetLineIndication[0] = this.findYLine(this.lastRoturaTargetLine);	
			} else {
				roturaTargetLineIndication[0] = 0.0;
			}			
			
			if (this.lastRoturaStopLine != null) {
				roturaStopLineIndication[0] = this.findYLine(this.lastRoturaStopLine);	
			} else {
				roturaStopLineIndication[0] = 0.0;
			}			
			
			close50Series[0] = this.close50;
		}
		
		protected double findSlope(DrawingTools.Line line) {
			double slope = (line.EndAnchor.Price - line.StartAnchor.Price) /(double)(line.EndAnchor.Time.Ticks - line.StartAnchor.Time.Ticks);
			return slope;
		}
		
		protected double findYLine(DrawingTools.Line line) {
			double slope = (line.EndAnchor.Price - line.StartAnchor.Price) /(double)(line.EndAnchor.Time.Ticks - line.StartAnchor.Time.Ticks);
			double y = line.StartAnchor.Price + slope * (Time[0].Ticks - line.StartAnchor.Time.Ticks);
			return y;
		}
		
		protected void detectLines() {
			//Print("Instruments.FullName " + Instrument);

			// Loops through the DrawObjects collection via a threadsafe list copy		
			this.lastSellLine = null;
			this.lastBuyLine = null;
			this.lastTargetLine = null;
			this.lastStopLine = null;
			this.lastRoturaSellLine = null;
			this.lastRoturaBuyLine = null;
			this.lastRoturaTargetLine = null;
			this.lastRoturaStopLine = null;
			
			foreach (DrawingTool draw in DrawObjects.ToList())
		    {
			    // Finds line objects that are attached globally to all charts of the same instrument
			    if (draw is DrawingTools.Line)
			    {
			        DrawingTools.Line globalLine = draw as DrawingTools.Line;
					
					//Print("Line Object: " + draw.Tag + " Manually Drawn: " + draw.IsUserDrawn);
			        //Print("Prices : " + globalLine.StartAnchor.Price + " End: " + globalLine.EndAnchor.Price);
			        //Print("Times : " + globalLine.StartAnchor.Time + " End: " + globalLine.EndAnchor.Time);		

					// Find last buy and sell lines
			    	if (draw.Tag.Length>0) {
						if (draw.Tag.ToUpper()[0] == 'S') {
							if (this.lastSellLine == null) this.lastSellLine = globalLine;
							else {
								if (globalLine.EndAnchor.Time > this.lastSellLine.EndAnchor.Time) this.lastSellLine = globalLine;
							}
						} else if (draw.Tag.ToUpper()[0] == 'B') {
							if (this.lastBuyLine == null) this.lastBuyLine = globalLine;
							else {
								if (globalLine.EndAnchor.Time > this.lastBuyLine.EndAnchor.Time) this.lastBuyLine = globalLine;								
							}							
						} else if (draw.Tag.ToUpper()[0] == 'T') {
							if (this.lastTargetLine == null) this.lastTargetLine = globalLine;
							else {
								if (globalLine.EndAnchor.Time > this.lastTargetLine.EndAnchor.Time) this.lastTargetLine = globalLine;								
							}							
						} else if (draw.Tag.ToUpper()[0] == 'X') {
							if (this.lastStopLine == null) this.lastStopLine = globalLine;
							else {
								if (globalLine.EndAnchor.Time > this.lastStopLine.EndAnchor.Time) this.lastStopLine = globalLine;								
							}							
						} else if (draw.Tag.Length>1 && draw.Tag.ToUpper()[0] == 'R' && draw.Tag.ToUpper()[1] == 'S') {
							if (this.lastRoturaSellLine == null) this.lastRoturaSellLine = globalLine;
							else {
								if (globalLine.EndAnchor.Time > this.lastRoturaSellLine.EndAnchor.Time) this.lastRoturaSellLine = globalLine;								
							}							
						} else if (draw.Tag.Length>1 && draw.Tag.ToUpper()[0] == 'R' && draw.Tag.ToUpper()[1] == 'B') {
							if (this.lastRoturaBuyLine == null) this.lastRoturaBuyLine = globalLine;
							else {
								if (globalLine.EndAnchor.Time > this.lastRoturaBuyLine.EndAnchor.Time) this.lastRoturaBuyLine = globalLine;								
							}							
						} else if (draw.Tag.Length>1 && draw.Tag.ToUpper()[0] == 'R' && draw.Tag.ToUpper()[1] == 'T') {
							if (this.lastRoturaTargetLine == null) this.lastRoturaTargetLine = globalLine;
							else {
								if (globalLine.EndAnchor.Time > this.lastRoturaTargetLine.EndAnchor.Time) this.lastRoturaTargetLine = globalLine;								
							}							
						} else if (draw.Tag.Length>1 && draw.Tag.ToUpper()[0] == 'R' && draw.Tag.ToUpper()[1] == 'X') {
							if (this.lastRoturaStopLine == null) this.lastRoturaStopLine  = globalLine;
							else {
								if (globalLine.EndAnchor.Time > this.lastRoturaStopLine .EndAnchor.Time) this.lastRoturaStopLine = globalLine;								
							}							
						}
					}
					
					//Print("draw.Tag[0] " + draw.Tag.ToUpper()[0]);
					//globalLine.Stroke.Brush = Brushes.Red;
					//globalLine.Brush = Brushes.Red;
					//RemoveDrawObject(globalLine.Tag.ToString());
				}
			}			
			
			foreach (DrawingTool draw in DrawObjects.ToList())
		    {
				if (draw is DrawingTools.Line)
			    {
			        DrawingTools.Line globalLine = draw as DrawingTools.Line;
					if (globalLine == this.lastSellLine) globalLine.Stroke = new Stroke(Brushes.Red, DashStyleHelper.Solid, 1);
					else if (globalLine == this.lastBuyLine) globalLine.Stroke = new Stroke(Brushes.Green, DashStyleHelper.Solid, 1);
					else if (globalLine == this.lastTargetLine) globalLine.Stroke = new Stroke(Brushes.Gold, DashStyleHelper.Solid, 1);
					else if (globalLine == this.lastStopLine) globalLine.Stroke = new Stroke(Brushes.DarkGray, DashStyleHelper.Solid, 1);
					else if (globalLine == this.lastRoturaSellLine) globalLine.Stroke = new Stroke(Brushes.Orange, DashStyleHelper.Solid, 1);
					else if (globalLine == this.lastRoturaBuyLine) globalLine.Stroke = new Stroke(Brushes.DarkSeaGreen, DashStyleHelper.Solid, 1);
					else if (globalLine == this.lastRoturaTargetLine) globalLine.Stroke = new Stroke(Brushes.Cyan, DashStyleHelper.Solid, 1);
					else if (globalLine == this.lastRoturaStopLine) globalLine.Stroke = new Stroke(Brushes.BlueViolet, DashStyleHelper.Solid, 1);
															
					else globalLine.Stroke.Brush = Brushes.Blue;					
				}
			}
			
			// Only sell or buy at same time
			if (this.lastBuyLine != null && this.lastSellLine != null) {
				if (this.lastSellLine.EndAnchor.Time > this.lastBuyLine.EndAnchor.Time) {
					this.lastBuyLine = null;
				} else {
					this.lastSellLine = null;
				}				
			}
			
			if (this.lastRoturaBuyLine != null && this.lastRoturaSellLine != null) {
				if (this.lastRoturaSellLine.EndAnchor.Time > this.lastRoturaBuyLine.EndAnchor.Time) {
					this.lastRoturaBuyLine = null;
				} else {
					this.lastRoturaSellLine = null;
				}				
			}
			
		}
		
		public override void OnCalculateMinMax()
		{
			double minValue = double.MaxValue;
			double maxValue = double.MinValue;

			foreach (TrendRay trend in trendLines)
				AutoScalePerRay(trend.Ray, ref minValue, ref maxValue);

			MinValue = minValue;
			MaxValue = maxValue;
		}

		// Controls
		protected void CreateWPFControls()
		{
			chartWindow	= System.Windows.Window.GetWindow(ChartControl.Parent) as NinjaTrader.Gui.Chart.Chart;
			chartGrid	= chartWindow.MainTabControl.Parent as System.Windows.Controls.Grid;

			//chartGrid.Background = BackBrush;

			// upper tool bar objects
			// upper tool bar menu
			topMenu = new System.Windows.Controls.Menu()
			{
				Background			= activeBackgroundDarkGray,
				BorderBrush			= controlLightGray,
				Padding				= new System.Windows.Thickness(0),
				Margin				= new System.Windows.Thickness(0),
				VerticalAlignment	= VerticalAlignment.Center,			
				HorizontalAlignment = HorizontalAlignment.Center
			};

			Style mmiStyle = Application.Current.TryFindResource("MainMenuItem") as Style;

			NinjaTrader.Gui.Tools.NTMenuItem topMenuItem1 = new Gui.Tools.NTMenuItem()
			{
				Background			= controlLightGray,
				Foreground			= textColor,
				Header				= "Draw Line     v",
				Margin				= new System.Windows.Thickness(0),
				Padding				= new System.Windows.Thickness(1),
				Style				= mmiStyle,
				VerticalAlignment	= VerticalAlignment.Center
			};

			ButtonSellCreek = new Gui.Tools.NTMenuItem()
			{
				Background			= Brushes.Red,
				BorderThickness		= new System.Windows.Thickness(0),
				Foreground			= textColor,
				Header				= "Sell Creek (S)"
			};

			ButtonSellCreek.Click += ButtonSellCreek_Click;
			topMenuItem1.Items.Add(ButtonSellCreek);

			ButtonBuyCreek = new Gui.Tools.NTMenuItem()
			{
				Background			= Brushes.Green,
				Foreground			= textColor,
				Header				= "Buy Creek (B)"
			};
			ButtonBuyCreek.Click += ButtonBuyCreek_Click;
			topMenuItem1.Items.Add(ButtonBuyCreek);
			
			
			ButtonTarget = new Gui.Tools.NTMenuItem()
			{
				Background			= Brushes.Gold,
				Foreground			= Brushes.Black,
				Header				= "Target (T)"
			};
			ButtonTarget.Click += ButtonTarget_Click;
			topMenuItem1.Items.Add(ButtonTarget);		

			ButtonStop = new Gui.Tools.NTMenuItem()
			{
				Background			= controlLightGray,
				Foreground			= Brushes.White,
				Header				= "Stop (X)"
			};
			ButtonStop.Click += ButtonStop_Click;
			topMenuItem1.Items.Add(ButtonStop);
			
			/*
			ButtonRoturaSell = new Gui.Tools.NTMenuItem()
			{
				Background			= Brushes.Orange,
				Foreground			= Brushes.Black,
				Header				= "Rotura SELL (RS)"
			};
			ButtonRoturaSell.Click += ButtonRoturaSell_Click;
			topMenuItem1.Items.Add(ButtonRoturaSell);
			
			ButtonRoturaBuy = new Gui.Tools.NTMenuItem()
			{
				Background			= Brushes.DarkSeaGreen,
				Foreground			= Brushes.Black,
				Header				= "Rotura BUY (RB)"
			};
			ButtonRoturaBuy.Click += ButtonRoturaBuy_Click;
			topMenuItem1.Items.Add(ButtonRoturaBuy);
			
			ButtonRoturaTarget = new Gui.Tools.NTMenuItem()
			{
				Background			= Brushes.Cyan,
				Foreground			= Brushes.Black,
				Header				= "Rotura Target (RT)"
			};
			ButtonRoturaTarget.Click += ButtonRoturaTarget_Click;
			topMenuItem1.Items.Add(ButtonRoturaTarget);
			
			ButtonRoturaStop = new Gui.Tools.NTMenuItem()
			{
				Background			= Brushes.BlueViolet,
				Foreground			= Brushes.White,
				Header				= "Rotura Stop (RX)"
			};
			ButtonRoturaStop.Click += ButtonRoturaStop_Click;
			topMenuItem1.Items.Add(ButtonRoturaStop);*/
			
			ButtonDeleteAll = new Gui.Tools.NTMenuItem()
			{
				Background			= Brushes.White,
				Foreground			= Brushes.Black,
				Header				= "Delete All Lines"
			};
			ButtonDeleteAll.Click += ButtonDeleteAll_Click;
			topMenuItem1.Items.Add(ButtonDeleteAll);
			
			ButtonDeleteTrading = new Gui.Tools.NTMenuItem()
			{
				Background			= Brushes.White,
				Foreground			= Brushes.Black,
				Header				= "Delete Entry Lines"
			};
			ButtonDeleteTrading.Click += ButtonDeleteTrading_Click;
			topMenuItem1.Items.Add(ButtonDeleteTrading);
			
			topMenu.Items.Add(topMenuItem1);
			
			/////////////////////////////////////////
			// Menu 2
			/////////////////////////////////////////

			NinjaTrader.Gui.Tools.NTMenuItem topMenuItem2 = new Gui.Tools.NTMenuItem()
			{
				Background			= controlLightGray,
				Foreground			= textColor,
				Header				= "TP 2 Levels v",
				Margin				= new System.Windows.Thickness(0),
				Padding				= new System.Windows.Thickness(1),
				Style				= mmiStyle,
				VerticalAlignment	= VerticalAlignment.Center
			};

			NinjaTrader.Gui.Tools.NTMenuItem Button1_Menu2 = new Gui.Tools.NTMenuItem()
			{
				Background			= Brushes.Orange,
				BorderThickness		= new System.Windows.Thickness(0),
				Foreground			= Brushes.Black,
				Header				= "Activate"
			};

			Button1_Menu2.Click += ActivateClose50_Click;
			topMenuItem2.Items.Add(Button1_Menu2);
			
			NinjaTrader.Gui.Tools.NTMenuItem Button2_Menu2 = new Gui.Tools.NTMenuItem()
			{
				Background			= Brushes.Gray,
				BorderThickness		= new System.Windows.Thickness(0),
				Foreground			= Brushes.White,
				Header				= "Deactivate"
			};

			Button2_Menu2.Click += DeactivateClose50_Click;
			topMenuItem2.Items.Add(Button2_Menu2);
			
			topMenu.Items.Add(topMenuItem2);
			
			this.addMenuItem("Sell Creek (S)", Brushes.Red, ButtonSellCreek_Click);
			this.addMenuItem("Buy Creek (B)", Brushes.Green, ButtonBuyCreek_Click);
			this.addMenuItem("Panic", Brushes.Black, ButtonDeleteAll_Click);
			
			// this allows us to make our menus stack vertically
			System.Windows.Controls.VirtualizingStackPanel VerticalStackPanel = new System.Windows.Controls.VirtualizingStackPanel()
			{
				Background			= activeBackgroundDarkGray,
				HorizontalAlignment	= HorizontalAlignment.Stretch,
				Orientation			= System.Windows.Controls.Orientation.Vertical,
				VerticalAlignment	= VerticalAlignment.Stretch
			};
			
			if (TabSelected())
				InsertWPFControls();

			chartWindow.MainTabControl.SelectionChanged += TabChangedHandler;
		}

		private void addMenuItem(string text, SolidColorBrush color, System.Windows.RoutedEventHandler TopMenuItem2_Click) {
			// upper tool bar button, has text and image
			System.Windows.Controls.MenuItem topMenuItem2 = new System.Windows.Controls.MenuItem()
			{
				Background			= controlLightGray,
				FontSize			= 12,
				Foreground			= textColor,
				Padding				= new System.Windows.Thickness(1),
				Margin				= new System.Windows.Thickness(5, 0, 5, 0)				
			};
			
			// this stackpanel allows us to place text and a picture horizontally in topMenuItem2
			System.Windows.Controls.StackPanel topMenuItem2StackPanel = new System.Windows.Controls.StackPanel()
			{
				Orientation			= System.Windows.Controls.Orientation.Horizontal,
				VerticalAlignment	= VerticalAlignment.Top,
				HorizontalAlignment	= HorizontalAlignment.Right
			};
			System.Windows.Controls.TextBlock newTextBlock = new System.Windows.Controls.TextBlock()
			{
				Background			= color,
				Foreground			= textColor,
				Text				= text
			};
			topMenuItem2StackPanel.Children.Add(newTextBlock);

			topMenuItem2.Header = topMenuItem2StackPanel;
			topMenuItem2.Click += TopMenuItem2_Click;
			topMenu.Items.Add(topMenuItem2);			
			
		}
		
		private void DisposeWPFControls()
		{
			if (ButtonSellCreek != null)
				ButtonSellCreek.Click -= ButtonSellCreek_Click;

			if (ButtonBuyCreek != null)
				ButtonBuyCreek.Click -= ButtonBuyCreek_Click;



			if (chartWindow != null)
				chartWindow.MainTabControl.SelectionChanged -= TabChangedHandler;

			RemoveWPFControls();
		}

		protected void InsertWPFControls()
		{
			if (panelActive)
				return;

			if (chartGrid.RowDefinitions.Count == 0)
				chartGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });

			tabControlStartRow		= System.Windows.Controls.Grid.GetRow(chartWindow.MainTabControl);

			chartGrid.RowDefinitions.Insert(tabControlStartRow, new System.Windows.Controls.RowDefinition() { Height = new GridLength(20) });

			// including the chartTabControl move all items right of the chart and below the chart to the right one column and down one row
			for (int i = 0; i < chartGrid.Children.Count; i++)
			{
				if (System.Windows.Controls.Grid.GetRow(chartGrid.Children[i]) >= tabControlStartRow)
					System.Windows.Controls.Grid.SetRow(chartGrid.Children[i], System.Windows.Controls.Grid.GetRow(chartGrid.Children[i]) + 1);
			}

			// set the columns and rows for our new items
			System.Windows.Controls.Grid.SetColumn(topMenu, System.Windows.Controls.Grid.GetColumn(chartWindow.MainTabControl));
			System.Windows.Controls.Grid.SetRow(topMenu, tabControlStartRow);

		
			chartGrid.Children.Add(topMenu);

			// let the script know the panel is active
			panelActive = true;
		}

		protected void RemoveWPFControls()
		{
			if (!panelActive)
				return;

			if (topMenu != null)
			{
				chartGrid.RowDefinitions.RemoveAt(System.Windows.Controls.Grid.GetRow(topMenu));
				chartGrid.Children.Remove(topMenu);
			}

			// if the childs column is 1 (so we can move it to 0) and the column is to the right of the column we are removing, shift it left
			for (int i = 0; i < chartGrid.Children.Count; i++)
			{
				if (System.Windows.Controls.Grid.GetRow(chartGrid.Children[i]) > 0 && System.Windows.Controls.Grid.GetRow(chartGrid.Children[i]) > System.Windows.Controls.Grid.GetRow(topMenu))
					System.Windows.Controls.Grid.SetRow(chartGrid.Children[i], System.Windows.Controls.Grid.GetRow(chartGrid.Children[i]) - 1);
			}

			panelActive = false;
		}

		private bool TabSelected()
		{
			bool tabSelected = false;

			// loop through each tab and see if the tab this indicator is added to is the selected item
			foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items)
				if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem)
					tabSelected = true;

			return tabSelected;
		}

		private void TabChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0)
				return;

			tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
			if (tabItem == null)
				return;

			chartTab = tabItem.Content as NinjaTrader.Gui.Chart.ChartTab;
			if (chartTab == null)
				return;

			if (TabSelected())
				InsertWPFControls();
			else
				RemoveWPFControls();
		}

		protected void ButtonSellCreek_Click(object sender, RoutedEventArgs e)
		{
			NinjaTrader.NinjaScript.DrawingTools.Line myLine = Draw.Line(this, "S", true, this.now.AddSeconds(-SECONDS_LINE_LENGTH), this.priceNow + 10 * TickSize, this.now, this.priceNow + 10 * TickSize, Brushes.Red, DashStyleHelper.Dash, 2); 
			myLine.IsLocked = false;
			ChartControl.InvalidateVisual();
		}

		
		protected void ButtonBuyCreek_Click(object sender, RoutedEventArgs e)
		{							
			NinjaTrader.NinjaScript.DrawingTools.Line myLine = Draw.Line(this, "B", true, this.now.AddSeconds(-SECONDS_LINE_LENGTH), this.priceNow - 10 * TickSize, this.now, this.priceNow - 10 * TickSize, Brushes.Green, DashStyleHelper.Dash, 2); 
			myLine.IsLocked = false;
			ChartControl.InvalidateVisual();
		}

		protected void ButtonTarget_Click(object sender, RoutedEventArgs e)
		{
			if (this.lastSellLine == null && this.lastBuyLine == null) return;
			int sign = 1;
			if (this.lastSellLine != null) sign = -1;
			
			NinjaTrader.NinjaScript.DrawingTools.Line myLine = Draw.Line(this, "T", true, this.now.AddSeconds(-SECONDS_LINE_LENGTH), this.priceNow + sign * 15 * TickSize, this.now, this.priceNow + sign * 15 * TickSize, Brushes.Gold, DashStyleHelper.Dash, 2); 
			myLine.IsLocked = false;
			ChartControl.InvalidateVisual();
		}
		
		protected void ButtonStop_Click(object sender, RoutedEventArgs e)
		{
			if (this.lastSellLine == null && this.lastBuyLine == null) return;
			int sign = 1;
			if (this.lastBuyLine != null) sign = -1;
			
			NinjaTrader.NinjaScript.DrawingTools.Line myLine = Draw.Line(this, "X", true, this.now.AddSeconds(-SECONDS_LINE_LENGTH), this.priceNow + sign * 15 * TickSize, this.now, this.priceNow + sign * 15 * TickSize, Brushes.DarkGray, DashStyleHelper.Dash, 2); 
			myLine.IsLocked = false;
			ChartControl.InvalidateVisual();
		}
		
		protected void ButtonRoturaSell_Click(object sender, RoutedEventArgs e)
		{	
			NinjaTrader.NinjaScript.DrawingTools.Line myLine = Draw.Line(this, "RS", true, this.now.AddSeconds(-SECONDS_LINE_LENGTH), this.priceNow - 10 * TickSize, this.now, this.priceNow - 10 * TickSize, Brushes.Orange, DashStyleHelper.Dash, 2); 
			myLine.IsLocked = false;
			ChartControl.InvalidateVisual();
		}

		protected void ButtonRoturaBuy_Click(object sender, RoutedEventArgs e)
		{	
			NinjaTrader.NinjaScript.DrawingTools.Line myLine = Draw.Line(this, "RB", true, this.now.AddSeconds(-SECONDS_LINE_LENGTH), this.priceNow + 10 * TickSize, this.now, this.priceNow + 10 * TickSize, Brushes.DarkSeaGreen, DashStyleHelper.Dash, 2); 
			myLine.IsLocked = false;
			ChartControl.InvalidateVisual();
		}


		protected void ButtonRoturaTarget_Click(object sender, RoutedEventArgs e)
		{	
			if (this.lastRoturaSellLine == null && this.lastRoturaBuyLine == null) return;
			int factor = 1;
			if (this.lastRoturaSellLine != null) factor = -1;
				
			NinjaTrader.NinjaScript.DrawingTools.Line myLine = Draw.Line(this, "RT", true, this.now.AddSeconds(-SECONDS_LINE_LENGTH), this.priceNow + 15 * factor * TickSize, this.now, this.priceNow + 15 * factor * TickSize, Brushes.Cyan, DashStyleHelper.Dash, 2); 
			myLine.IsLocked = false;
			ChartControl.InvalidateVisual();
		}
		
		protected void ButtonRoturaStop_Click(object sender, RoutedEventArgs e)
		{	
			if (this.lastRoturaSellLine == null && this.lastRoturaBuyLine == null) return;
			int factor = 1;
			if (this.lastRoturaSellLine != null) factor = -1;
			
			NinjaTrader.NinjaScript.DrawingTools.Line myLine = Draw.Line(this, "RX", true, this.now.AddSeconds(-SECONDS_LINE_LENGTH), this.priceNow - 15 * factor * TickSize, this.now, this.priceNow - 15 * factor * TickSize, Brushes.BlueViolet, DashStyleHelper.Dash, 2); 
			myLine.IsLocked = false;
			ChartControl.InvalidateVisual();
		}
		
		protected void ButtonDeleteAll_Click(object sender, RoutedEventArgs e)
		{
			RemoveDrawObject("S");
			RemoveDrawObject("B");
			RemoveDrawObject("T");
			RemoveDrawObject("X");
			RemoveDrawObject("RS");
			RemoveDrawObject("RB");
			RemoveDrawObject("RT");
			RemoveDrawObject("RX");
			
			ChartControl.InvalidateVisual();
		}
		
		protected void ButtonDeleteTrading_Click(object sender, RoutedEventArgs e)
		{
			RemoveDrawObject("S");
			RemoveDrawObject("B");
			RemoveDrawObject("RS");
			RemoveDrawObject("RB");
			
			ChartControl.InvalidateVisual();
		}
		
		protected void ActivateClose50_Click(object sender, RoutedEventArgs e)
		{
			this.changeClose50(true);
		}
		
		protected void DeactivateClose50_Click(object sender, RoutedEventArgs e)
		{
			this.changeClose50(false);
		}
		
		private void changeClose50(bool value) {
			this.close50 = value;
			if (this.close50) {
				this.setStatus("Take Profit 2 Levels ACTIVE", Brushes.Orange);
			} else {
				this.setStatus("Take Profit 2 Levels INACTIVE", Brushes.Gray);
			}
		}
		
		protected void setStatus(string text, SolidColorBrush color)
		{
			Draw.TextFixed(this, "infobox", text, TextPosition.BottomLeft, color, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			// only invalidate the chart so that the text box will appear even if there is no incoming data
			ChartControl.InvalidateVisual();
		}		

		#region Helpers
		private void AutoScalePerRay(Ray ray, ref double minValue, ref double maxValue)
		{
			int startIdx = ChartBars.GetBarIdxByTime(ChartControl, ray.StartAnchor.Time);

			if (startIdx >= ChartBars.FromIndex - Displacement && startIdx <= ChartBars.ToIndex - Displacement)
			{
				if (ray.StartAnchor.Price < minValue)
					minValue = ray.StartAnchor.Price;
				if (ray.StartAnchor.Price > maxValue)
					maxValue = ray.StartAnchor.Price;
			}

			int endIdx = ChartBars.GetBarIdxByTime(ChartControl, ray.EndAnchor.Time);

			if (endIdx >= ChartBars.FromIndex - Displacement && endIdx <= ChartBars.ToIndex - Displacement)
			{
				if (ray.EndAnchor.Price < minValue)
					minValue = ray.EndAnchor.Price;
				if (ray.EndAnchor.Price > maxValue)
					maxValue = ray.EndAnchor.Price;
			}
		}

		private class TrendRay
		{
			public int		StartBar;
			public double	StartPrice;
			public int		EndBar;
			public double	EndPrice;
			public Ray		Ray;
			public bool		IsHigh;

			public TrendRay(int startBar, double startPrice, int endBar, double endPrice)
			{
				StartBar	= startBar;
				StartPrice	= startPrice;
				EndBar		= endBar;
				EndPrice	= endPrice;
			}
		}

		private class TrendQueue : Queue<TrendRay>
		{
			private AATradingLines	instance;
			private TrendRay	lastTrend;

			public new void Enqueue(TrendRay trend)
			{
				if (instance.ChartControl != null)
				{
					string rayName	= string.Format("{0}_{1}", trend.IsHigh ? NinjaTrader.Custom.Resource.TrendLinesTrendLineHigh : NinjaTrader.Custom.Resource.TrendLinesTrendLineLow, trend.StartBar);
					trend.Ray		= Draw.Ray(instance,
												rayName,
												false,
												instance.CurrentBar - trend.StartBar - instance.Displacement,
												trend.StartPrice,
												instance.CurrentBar - trend.EndBar - instance.Displacement,
												trend.EndPrice,
												trend.IsHigh ? instance.TrendLineHighStroke.Brush : instance.TrendLineLowStroke.Brush,
												trend.IsHigh ? instance.TrendLineHighStroke.DashStyleHelper : instance.TrendLineLowStroke.DashStyleHelper,
												(int)(trend.IsHigh ? instance.TrendLineHighStroke.Width : instance.TrendLineLowStroke.Width));

					trend.Ray.Stroke.Opacity = trend.IsHigh ? instance.TrendLineHighStroke.Opacity : instance.TrendLineLowStroke.Opacity;

					if (lastTrend != null)
						lastTrend.Ray.Stroke.Opacity = instance.OldTrendsOpacity;
				}

				lastTrend = trend;
				base.Enqueue(trend);

				// Make it into a circular buffer
				if (Count > instance.NumberOfTrendLines)
				{
					TrendRay toRemove = base.Dequeue();

					// Ray will be null if no ChartControl
					if (toRemove.Ray != null)
						instance.RemoveDrawObject(toRemove.Ray.Tag);
				}
			}

			public TrendQueue(AATradingLines instance, int capacity) : base(capacity)
			{
				this.instance = instance;
			}
		}
		#endregion

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Strength", GroupName = "NinjaScriptParameters", Order = 0)]
		public int Strength { get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "NumberOfTrendLines", GroupName = "NinjaScriptParameters", Order = 1)]
		public int NumberOfTrendLines { get; set; }

		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "OldTrendsOpacity", GroupName = "NinjaScriptParameters", Order = 2)]
		public int OldTrendsOpacity { get; set; }

		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "AlertOnBreak", GroupName = "NinjaScriptParameters", Order = 3)]
		public bool AlertOnBreak { get; set; }

		[PropertyEditor("NinjaTrader.Gui.Tools.FilePathPicker", Filter = "WAV Files (*.wav)|*.wav")]
		[Display(ResourceType = typeof(Custom.Resource), Name = "AlertOnBreakSound", GroupName = "NinjaScriptParameters", Order = 4)]
		public string AlertOnBreakSound { get; set; }

		[Display(ResourceType = typeof(Custom.Resource), Name = "AATradingLines", GroupName = "NinjaScriptIndicatorVisualGroup", Order = 1800)]
		public Stroke TrendLineHighStroke { get; set; }

		[Display(ResourceType = typeof(Custom.Resource), Name = "AATradingLines", GroupName = "NinjaScriptIndicatorVisualGroup", Order = 1810)]
		public Stroke TrendLineLowStroke { get; set; }
	
		
		[Browsable(false)]
		[XmlIgnore]
        public Series<double> SellLineIndication
        {
            get { return sellLineIndication; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }	
		
		[Browsable(false)]
		[XmlIgnore]
        public Series<double> BuyLineIndication
        {
            get { return buyLineIndication; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }	
		
		[Browsable(false)]
		[XmlIgnore]
        public Series<double> TargetLineIndication
        {
            get { return targetLineIndication; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }	
		
		[Browsable(false)]
		[XmlIgnore]
        public Series<double> StopLineIndication
        {
            get { return stopLineIndication; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }	
		
		[Browsable(false)]
		[XmlIgnore]
        public Series<double> RoturaSellLineIndication
        {
            get { return roturaSellLineIndication; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }	
		
		[Browsable(false)]
		[XmlIgnore]
        public Series<double> RoturaBuyLineIndication
        {
            get { return roturaBuyLineIndication; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }	
		
		[Browsable(false)]
		[XmlIgnore]
        public Series<double> RoturaTargetLineIndication
        {
            get { return roturaTargetLineIndication; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }	
		
		[Browsable(false)]
		[XmlIgnore]
        public Series<double> RoturaStopLineIndication
        {
            get { return roturaStopLineIndication; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }
		
		[Browsable(false)]
		[XmlIgnore]
        public Series<double> SellSlopeIndication
        {
            get { return sellSlopeIndication; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }	
		
		[Browsable(false)]
		[XmlIgnore]
        public Series<double> BuySlopeIndication
        {
            get { return buySlopeIndication; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }	
		
		[Browsable(false)]
		[XmlIgnore]
        public Series<bool> Close50Series
        {
            get { return close50Series; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }		
		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AATradingLines[] cacheAATradingLines;
		public AATradingLines AATradingLines(int strength, int numberOfTrendLines, int oldTrendsOpacity, bool alertOnBreak)
		{
			return AATradingLines(Input, strength, numberOfTrendLines, oldTrendsOpacity, alertOnBreak);
		}

		public AATradingLines AATradingLines(ISeries<double> input, int strength, int numberOfTrendLines, int oldTrendsOpacity, bool alertOnBreak)
		{
			if (cacheAATradingLines != null)
				for (int idx = 0; idx < cacheAATradingLines.Length; idx++)
					if (cacheAATradingLines[idx] != null && cacheAATradingLines[idx].Strength == strength && cacheAATradingLines[idx].NumberOfTrendLines == numberOfTrendLines && cacheAATradingLines[idx].OldTrendsOpacity == oldTrendsOpacity && cacheAATradingLines[idx].AlertOnBreak == alertOnBreak && cacheAATradingLines[idx].EqualsInput(input))
						return cacheAATradingLines[idx];
			return CacheIndicator<AATradingLines>(new AATradingLines(){ Strength = strength, NumberOfTrendLines = numberOfTrendLines, OldTrendsOpacity = oldTrendsOpacity, AlertOnBreak = alertOnBreak }, input, ref cacheAATradingLines);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AATradingLines AATradingLines(int strength, int numberOfTrendLines, int oldTrendsOpacity, bool alertOnBreak)
		{
			return indicator.AATradingLines(Input, strength, numberOfTrendLines, oldTrendsOpacity, alertOnBreak);
		}

		public Indicators.AATradingLines AATradingLines(ISeries<double> input , int strength, int numberOfTrendLines, int oldTrendsOpacity, bool alertOnBreak)
		{
			return indicator.AATradingLines(input, strength, numberOfTrendLines, oldTrendsOpacity, alertOnBreak);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AATradingLines AATradingLines(int strength, int numberOfTrendLines, int oldTrendsOpacity, bool alertOnBreak)
		{
			return indicator.AATradingLines(Input, strength, numberOfTrendLines, oldTrendsOpacity, alertOnBreak);
		}

		public Indicators.AATradingLines AATradingLines(ISeries<double> input , int strength, int numberOfTrendLines, int oldTrendsOpacity, bool alertOnBreak)
		{
			return indicator.AATradingLines(input, strength, numberOfTrendLines, oldTrendsOpacity, alertOnBreak);
		}
	}
}

#endregion
