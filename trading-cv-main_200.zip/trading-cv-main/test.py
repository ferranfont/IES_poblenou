import os
from main import Main

# capturing video
file_img = input(f'nombre y extensión de la captura: ')
Main("./inputs/" + file_img)


