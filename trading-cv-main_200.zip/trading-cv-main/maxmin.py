# imports
# cv2- image processing library
# function- all the functions required imported from fucntions.py (written by me)
import cv2
import function as fc
from calc.Extrems import Extrems
import time
import os


BLACK_COLOR = 55


class Main:

    bgColor = "black"
    fgColor = "white"

    def __init__(self):
        # Video path
        filename = "./videos/Against the trend_3.mp4"

        red = (0, 0, 255)
        yellow = (0, 255, 255)

        # capturing video
        cap = cv2.VideoCapture(filename)
        startTime = time.time()
        # directory to store screenshots
        save_directory = 'images'
        os.makedirs(save_directory, exist_ok=True)

        # get vcap property
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))   # float `width`
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        # Divide resolution by 4
        width = (int)(width / 4)
        height = (int)(height / 4)

        frameCount = 0
        while cap.isOpened():
            # cap.set(cv2.CAP_PROP_POS_FRAMES, 250)
            success, img = cap.read()

            if success:
                img = cv2.resize(img, (width, height))

                # To gray scale
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

                extrems = Extrems(gray, width, height)
                points = extrems.getExtrems()

                # displaying all the local extremes
                for point in points:
                    if point.isMax:
                        cv2.circle(img, (point.x, point.y - 3),
                                   1, (255, 255, 0), 1)
                    else:
                        cv2.circle(img, (point.x, point.y + 3),
                                   1, (255, 0, 255), 1)

                screenshot_path = os.path.join(
                    save_directory, f'screenshot_{int(time.time())}.png')
                cv2.imwrite(screenshot_path, img)

                frameCount += 250  # i.e. at 25 fps, this advances one second
                cap.set(cv2.CAP_PROP_POS_FRAMES, frameCount)

            else:
                cap.release()
                break

    #
    def getXofCurrentTime(self, width, height, frame):
        """Get the x of current time, so no need to search after this x value"""
        for x in range(0, width):
            if frame[0, x] > BLACK_COLOR and frame[height-1, x] > BLACK_COLOR:
                return x
        return width

    def main():
        pass


run = Main()
